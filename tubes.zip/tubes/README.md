Aplikasi sederhana jasa cuci kendaraan dengan PHP MySQLi.
---
Fitur:
- Multi user.
- Data master
- Cetak Nota
- Laporan

Ini adalah source code dari https://masrud.com/post/aplikasi-cuci-mobil-motor-php-mysqli
